log_level        :info
log_location     STDOUT
chef_repo_path 	  "/vagrant/chef-repo/centos7"
cookbook_path	"/vagrant/chef-repo/centos7/cookbooks"
role_path		"/vagrant/chef-repo/centos7/roles"